import { useReducer } from 'react'

const FAHRZEUGE = [
  { label: 'VW ID.3', verbrauch: 167 },
  { label: 'VW ID.4', verbrauch: 174 },
  { label: 'VW ID.5', verbrauch: 171 },
  { label: 'Škoda Enyaq', verbrauch: 160 },
  { label: 'Cupra Born', verbrauch: 157 },
  { label: 'Audi Q4 e-tron', verbrauch: 179 },
]

type EingabeModus = 'gesamt' | 'proTag'

type State = {
  fahrzeugIndex: number
  eingabeModus: EingabeModus
  energieWh: string
  anzahlTage: string
  kWhProTag: string
  ergebnis: { energie: number; verbrauch: number; distanz: number } | null
}

type Action =
  | { type: 'SET_FAHRZEUG'; index: number }
  | { type: 'SET_MODUS'; modus: EingabeModus }
  | { type: 'SET_ENERGIE'; value: string }
  | { type: 'SET_TAGE'; value: string }
  | { type: 'SET_KWH_PRO_TAG'; value: string }
  | { type: 'BERECHNEN' }
  | { type: 'RESET' }

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'SET_FAHRZEUG':
      return { ...state, fahrzeugIndex: action.index, ergebnis: null }
    case 'SET_MODUS':
      return { ...state, eingabeModus: action.modus, ergebnis: null }
    case 'SET_ENERGIE':
      return { ...state, energieWh: action.value, ergebnis: null }
    case 'SET_TAGE':
      return { ...state, anzahlTage: action.value, ergebnis: null }
    case 'SET_KWH_PRO_TAG':
      return { ...state, kWhProTag: action.value, ergebnis: null }
    case 'BERECHNEN': {
      let energieKWh: number
      if (state.eingabeModus === 'proTag') {
        const tage = parseFloat(state.anzahlTage)
        const proTag = parseFloat(state.kWhProTag)
        if (isNaN(tage) || tage <= 0 || isNaN(proTag) || proTag <= 0) return state
        energieKWh = tage * proTag
      } else {
        energieKWh = parseFloat(state.energieWh)
        if (isNaN(energieKWh) || energieKWh <= 0) return state
      }
      const energie = energieKWh * 1000 // kWh → Wh
      const verbrauch = FAHRZEUGE[state.fahrzeugIndex].verbrauch
      const distanz = energie / verbrauch
      return { ...state, ergebnis: { energie, verbrauch, distanz } }
    }
    case 'RESET':
      return { fahrzeugIndex: 0, eingabeModus: 'gesamt', energieWh: '', anzahlTage: '', kWhProTag: '', ergebnis: null }
    default:
      return state
  }
}

const initialState: State = {
  fahrzeugIndex: 0,
  eingabeModus: 'gesamt',
  energieWh: '',
  anzahlTage: '',
  kWhProTag: '',
  ergebnis: null,
}

function formatDE(value: number, decimals = 1): string {
  return value.toLocaleString('de-DE', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

export default function BiDiCalculator() {
  const [state, dispatch] = useReducer(reducer, initialState)

  const handleBerechnen = () => {
    dispatch({ type: 'BERECHNEN' })
  }

  const isValid = state.eingabeModus === 'proTag'
    ? state.anzahlTage !== '' && !isNaN(parseFloat(state.anzahlTage)) && parseFloat(state.anzahlTage) > 0
      && state.kWhProTag !== '' && !isNaN(parseFloat(state.kWhProTag)) && parseFloat(state.kWhProTag) > 0
    : state.energieWh !== '' && !isNaN(parseFloat(state.energieWh)) && parseFloat(state.energieWh) > 0

  return (
    <div className="min-h-screen bg-gray-50 flex items-start justify-center p-6">
      <div className="w-full max-w-lg">
        {/* Header */}
        <div
          className="rounded-t-2xl px-8 py-6 text-white"
          style={{ backgroundColor: '#005ea5' }}
        >
          <div className="flex items-center gap-3 mb-1">
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none" aria-hidden="true">
              <circle cx="16" cy="16" r="15" stroke="white" strokeWidth="2" />
              <path d="M10 22 L16 8 L22 22" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M12 18 H20" stroke="white" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <div>
              <h1 className="text-xl font-bold leading-tight">VW BiDi Virtuelle Distanz</h1>
              <p className="text-sm opacity-80">Bidirektionales Laden – Reichweitenrechner</p>
            </div>
          </div>
        </div>

        {/* Card */}
        <div className="bg-white rounded-b-2xl shadow-lg px-8 py-6 space-y-5">
          {/* Fahrzeugauswahl */}
          <div>
            <label
              htmlFor="fahrzeug"
              className="block text-sm font-semibold text-gray-700 mb-1"
            >
              Fahrzeugmodell
            </label>
            <select
              id="fahrzeug"
              value={state.fahrzeugIndex}
              onChange={(e) =>
                dispatch({ type: 'SET_FAHRZEUG', index: parseInt(e.target.value) })
              }
              className="w-full border border-gray-300 rounded-lg px-3 py-2.5 text-gray-800 focus:outline-none focus:ring-2 focus:border-transparent"
              style={{ '--tw-ring-color': '#005ea5' } as React.CSSProperties}
            >
              {FAHRZEUGE.map((f, i) => (
                <option key={f.label} value={i}>
                  {f.label} – {f.verbrauch} Wh/km
                </option>
              ))}
            </select>
          </div>

          {/* Eingabemodus */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              Eingabemodus
            </label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => dispatch({ type: 'SET_MODUS', modus: 'gesamt' })}
                className="flex-1 py-2 px-3 rounded-lg text-sm font-medium border transition-colors"
                style={
                  state.eingabeModus === 'gesamt'
                    ? { backgroundColor: '#005ea5', color: 'white', borderColor: '#005ea5' }
                    : { backgroundColor: 'white', color: '#374151', borderColor: '#d1d5db' }
                }
              >
                Gesamt kWh
              </button>
              <button
                type="button"
                onClick={() => dispatch({ type: 'SET_MODUS', modus: 'proTag' })}
                className="flex-1 py-2 px-3 rounded-lg text-sm font-medium border transition-colors"
                style={
                  state.eingabeModus === 'proTag'
                    ? { backgroundColor: '#005ea5', color: 'white', borderColor: '#005ea5' }
                    : { backgroundColor: 'white', color: '#374151', borderColor: '#d1d5db' }
                }
              >
                Tage &times; kWh/Tag
              </button>
            </div>
          </div>

          {/* Energieeingabe */}
          {state.eingabeModus === 'gesamt' ? (
            <div>
              <label
                htmlFor="energie"
                className="block text-sm font-semibold text-gray-700 mb-1"
              >
                Entladene Energie (V2H + V2L)
              </label>
              <div className="relative">
                <input
                  id="energie"
                  type="number"
                  min="0"
                  placeholder="z. B. 12"
                  value={state.energieWh}
                  onChange={(e) =>
                    dispatch({ type: 'SET_ENERGIE', value: e.target.value })
                  }
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 pr-14 text-gray-800 focus:outline-none focus:ring-2 focus:border-transparent"
                  style={{ '--tw-ring-color': '#005ea5' } as React.CSSProperties}
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm font-medium">
                  kWh
                </span>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div>
                <label
                  htmlFor="tage"
                  className="block text-sm font-semibold text-gray-700 mb-1"
                >
                  Anzahl der Tage
                </label>
                <input
                  id="tage"
                  type="number"
                  min="1"
                  step="1"
                  placeholder="z. B. 30"
                  value={state.anzahlTage}
                  onChange={(e) =>
                    dispatch({ type: 'SET_TAGE', value: e.target.value })
                  }
                  className="w-full border border-gray-300 rounded-lg px-3 py-2.5 text-gray-800 focus:outline-none focus:ring-2 focus:border-transparent"
                  style={{ '--tw-ring-color': '#005ea5' } as React.CSSProperties}
                />
              </div>
              <div>
                <label
                  htmlFor="kwhProTag"
                  className="block text-sm font-semibold text-gray-700 mb-1"
                >
                  Entladene Energie pro Tag (V2H + V2L)
                </label>
                <div className="relative">
                  <input
                    id="kwhProTag"
                    type="number"
                    min="0"
                    step="0.1"
                    placeholder="z. B. 5"
                    value={state.kWhProTag}
                    onChange={(e) =>
                      dispatch({ type: 'SET_KWH_PRO_TAG', value: e.target.value })
                    }
                    className="w-full border border-gray-300 rounded-lg px-3 py-2.5 pr-18 text-gray-800 focus:outline-none focus:ring-2 focus:border-transparent"
                    style={{ '--tw-ring-color': '#005ea5' } as React.CSSProperties}
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm font-medium">
                    kWh/Tag
                  </span>
                </div>
              </div>
              {state.anzahlTage && state.kWhProTag && parseFloat(state.anzahlTage) > 0 && parseFloat(state.kWhProTag) > 0 && (
                <p className="text-xs text-gray-500">
                  Gesamt: {formatDE(parseFloat(state.anzahlTage) * parseFloat(state.kWhProTag), 1)} kWh
                </p>
              )}
            </div>
          )}

          {/* Berechnen-Button */}
          <button
            onClick={handleBerechnen}
            disabled={!isValid}
            className="w-full py-3 rounded-lg text-white font-semibold transition-opacity disabled:opacity-40 disabled:cursor-not-allowed"
            style={{ backgroundColor: '#005ea5' }}
          >
            Virtuelle Distanz berechnen
          </button>

          {/* Ergebnis */}
          {state.ergebnis && (
            <div
              className="rounded-xl p-5 space-y-3"
              style={{ backgroundColor: '#e8f1f9' }}
            >
              <h2
                className="text-sm font-bold uppercase tracking-wide"
                style={{ color: '#005ea5' }}
              >
                Ergebnis
              </h2>
              <div className="space-y-2 text-sm text-gray-700">
                <div className="flex justify-between">
                  <span>Entladene Energie:</span>
                  <span className="font-semibold">
                    {formatDE(state.ergebnis.energie, 0)} Wh
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Verbrauchswert (WLTP worst-case):</span>
                  <span className="font-semibold">
                    {state.ergebnis.verbrauch} Wh/km
                  </span>
                </div>
                <div
                  className="flex justify-between pt-2 border-t text-base font-bold"
                  style={{ borderColor: '#b3cfe8', color: '#005ea5' }}
                >
                  <span>Virtuelle Distanz:</span>
                  <span>{formatDE(state.ergebnis.distanz, 1)} km</span>
                </div>
              </div>
            </div>
          )}

          {/* Formel */}
          <div className="rounded-xl border border-gray-200 px-4 py-3 text-xs text-gray-500">
            <p className="font-semibold text-gray-600 mb-1">Formel:</p>
            <p className="font-mono">
              Virtuelle Distanz [km] = Summe der entladenen Energie durch V2H + V2L [Wh] ÷ ungünstigster zertifizierter Energieverbrauchswert der Fahrzeugfamilie [Wh/km]
            </p>
          </div>

          {/* Info-Bereich */}
          <div
            className="rounded-xl p-4 text-xs space-y-2"
            style={{ backgroundColor: '#f0f4f8' }}
          >
            <h3 className="font-semibold text-gray-700">Hinweis zur Berechnung</h3>
            <p className="text-gray-600 leading-relaxed">
              Die angezeigten Verbrauchswerte entsprechen den <strong>Worst-Case-WLTP-Werten</strong> der
              jeweiligen Fahrzeugfamilie. Sie stellen den ungünstigsten zertifizierten
              Energieverbrauch dar und gewährleisten eine konservative Schätzung der virtuellen Distanz.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Die <strong>virtuelle Distanz</strong> wird zur realen Fahrleistung addiert, um den
              vollständigen Batterie-Lebenszyklus abzubilden – also die gesamte Energiemenge, die
              die Batterie in ihrem Leben aufgenommen und abgegeben hat (real + virtuell).
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
