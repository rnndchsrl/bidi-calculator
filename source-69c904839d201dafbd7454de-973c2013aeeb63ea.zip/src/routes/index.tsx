import { createFileRoute } from '@tanstack/react-router'
import BiDiCalculator from '../components/BiDiCalculator'

export const Route = createFileRoute('/')({
  component: Home,
})

function Home() {
  return <BiDiCalculator />
}
